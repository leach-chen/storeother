<template>
  <div id="apppage">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'  
}
</script>

<style lang="less">
  @import '~@/common/styles/base.less';

#apppage {
  width: 100%;
  height: 100%;
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
